const fs = require('fs');
const snowflake = require('snowflake-sdk');

function getToken() {
  console.info('Retrieving SF oauth token mounted by service');
  const token = fs.readFileSync('/snowflake/session/token', 'utf8');
  return token; 
}

function getConnection() {
  const token = getToken();
  const connection = snowflake.createConnection({
    application: 'helloworldspcs',
    account: process.env.SNOWFLAKE_ACCOUNT,
    host: process.env.SNOWFLAKE_HOST,
    database: process.env.SNOWFLAKE_DATABASE,
    schema: process.env.SNOWFLAKE_SCHEMA,
    warehouse: process.env.SF_WAREHOUSE,
    authenticator: 'OAUTH',
    token
  });
  return connection;
}

async function createSnowflakeConnection() {

  const connection = getConnection();
  await new Promise((resolve, reject) => {
    connection.connect( 
      function(err, conn) {
          if (err) {
            console.error('Failure connecting to snowflake ' + JSON.stringify(err));
            reject(err);
          } 
          else {
              console.info('Successfully connected to Snowflake.');
              resolve(conn.getId())
          }
      }
    );
  });

  return connection;
}

async function executeSqlStatement(connection, sqlText, binds) {
  console.info('Executing SQL statement: ' + sqlText);
  return new Promise((resolve, reject) => {
    connection.execute({
       sqlText,
       binds,
       complete: function(err, stmt, rows) {
         if (err) {
           console.error(`Failed to execute statement due to the following error: ${err.message}`);
           reject(err);
         } else {
           console.info('Success');
           resolve(rows);
         }
       }
     });
   });
}

module.exports = {
  getToken,
  getConnection,
  createSnowflakeConnection,
  executeSqlStatement,
}