// app.js
console.info('Starting app');

const express = require('express');
const spcsUtils = require('./spcs-utils.js');
const redis = require('redis');
const app = express();
const port = process.env.PORT || 3000; // Define the port the server will listen on.

const REDIS_SERVICE_NAME = process.env.REDIS_SERVICE_NAME;
const REDIS_SERVICE_PORT = process.env.REDIS_SERVICE_PORT;

console.info('Running with env', process.env);

let redisClient;

async function initRedisClient() {
  const url = `redis://${REDIS_SERVICE_NAME}:${REDIS_SERVICE_PORT}`;
  console.info('Connecting to redis client', url)
  const client = await redis.createClient({
      url
    })
    .on("error", (err) => console.log("Redis Client Error", err))
    .connect();
  return client;
}

// Middleware to log to Redis
app.use(async (req, res, next) => {
  try {
    console.info('Logging request');

    if (!redisClient) {
      redisClient = await initRedisClient();
    }

    const currentUser = req.headers['sf-context-current-user'] || 'anonymous';
    const route = req.path;
    const timestamp = new Date().toISOString();
    const key = 'logs';
    const value = `${timestamp}|${currentUser}|${route}`;

    // Use Redis client methods
    await redisClient.lPush(key, value);
    await redisClient.expire(key, 604800); // 1 week

    next();
  } catch (error) {
    console.error('Error logging request', error)
    res.status(500).json({
      error: error.message
    });
  }

});

app.get('/', (req, res) => {
  res.json({ message: 'Hello from your simple Express.js application!' });
});

// API endpoint to get request headers
app.get('/api/headers', (req, res) => {
  console.log('Returning header information', req.headers)
  res.json({
    headers: req.headers,
    ip: req.ip,
    method: req.method,
    url: req.url,
    timestamp: new Date().toISOString()
  });
});

// API endpoint to get all Redis data
app.get('/api/redis', async (req, res) => {
  try {
    const logs = await redisClient.lRange('logs', 0, -1);
  
    const parsedLogs = logs.map(log => {
      const logEntries = log.split('|');
      return {
        timestamp: logEntries[0],
        user: logEntries[1],
        route: logEntries[2]
      };
    });

    res.json({
      logsLastWeek: parsedLogs
    });
  } catch (e) {
    res.json({
      error: e.message
    });
  }
});

// API endpoint to query Snowflake table
app.get('/api/query', async (req, res) => {
  try {
    const query = 'SELECT * FROM helloworldspcs_db.helloworldspcs_schema.MY_TEST_TABLE';
    
    const connection = await spcsUtils.createSnowflakeConnection();
    
    const result = await spcsUtils.executeSqlStatement(connection, query);

    res.json({
      data: result,
      rowCount: result.length
    });
  } catch (error) {
    console.error('Error executing query:', error);
    res.status(500).json({
      error: error.message
    });
  }
});


// Start the server and listen for incoming requests on the specified port.
app.listen(port, () => {
  console.log(`Express app listening at http://localhost:${port}`);
  console.log('Access the endpoint at http://localhost:3000/');
});
