

Here are the docker commands to build and push each of the 3 images to the image repo.


```
docker build --rm --platform linux/amd64 -f Dockerfile -t tqpzuaf-osa60413.registry.snowflakecomputing.com/helloworldspcs_db/helloworldspcs_schema/img_repo/helloworld_frontend:latest .
docker push tqpzuaf-osa60413.registry.snowflakecomputing.com/helloworldspcs_db/helloworldspcs_schema/img_repo/helloworld_frontend:latest
```


```
docker build --rm --platform linux/amd64 -f Dockerfile -t tqpzuaf-osa60413.registry.snowflakecomputing.com/helloworldspcs_db/helloworldspcs_schema/img_repo/helloworld_backend:latest .
docker push tqpzuaf-osa60413.registry.snowflakecomputing.com/helloworldspcs_db/helloworldspcs_schema/img_repo/helloworld_backend:latest
```


```
docker pull amd64/redis
docker tag amd64/redis:latest tqpzuaf-osa60413.registry.snowflakecomputing.com/helloworldspcs_db/helloworldspcs_schema/img_repo/redis:latest
docker push tqpzuaf-osa60413.registry.snowflakecomputing.com/helloworldspcs_db/helloworldspcs_schema/img_repo/redis:latest
```