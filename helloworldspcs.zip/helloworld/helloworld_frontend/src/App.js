import logo from './logo.svg';
import './App.css';
import { useState } from 'react';

function App() {
  const [headers, setHeaders] = useState(null);
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);

  const fetchHeaders = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/headers');
      const data = await response.json();
      setHeaders(data);
    } catch (error) {
      console.error('Error fetching headers:', error);
    } finally {
      setLoading(false);
    }
  };
  const fetchData = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/query');
      const data = await response.json();
      setData(data);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Hello World Frontend with Express Server
        </p>
        <button 
          onClick={fetchHeaders}
          disabled={loading}
          style={{
            padding: '10px 20px',
            fontSize: '16px',
            backgroundColor: '#61dafb',
            border: 'none',
            borderRadius: '5px',
            cursor: 'pointer',
            marginBottom: '20px'
          }}
        >
          {loading ? 'Loading...' : 'Get Request Headers'}
        </button>
        <button 
          onClick={fetchData}
          disabled={loading}
          style={{
            padding: '10px 20px',
            fontSize: '16px',
            backgroundColor: '#61dafb',
            border: 'none',
            borderRadius: '5px',
            cursor: 'pointer',
            marginBottom: '20px'
          }}
        >
          {loading ? 'Loading...' : 'Get table data'}
        </button>
        
        {headers && (
          <div style={{ 
            textAlign: 'left', 
            backgroundColor: '#282c34', 
            padding: '20px', 
            borderRadius: '10px',
            maxWidth: '80%',
            maxHeight: '400px',
            overflow: 'auto'
          }}>
            <h3>Request Information:</h3>
            <pre style={{ fontSize: '12px', color: '#61dafb' }}>
              {JSON.stringify(headers, null, 2)}
            </pre>
          </div>
        )}

        {data && (
          <div style={{ 
            textAlign: 'left', 
            backgroundColor: '#282c34', 
            padding: '20px', 
            borderRadius: '10px',
            maxWidth: '80%',
            maxHeight: '400px',
            overflow: 'auto'
          }}>
            <h3>Table data:</h3>
            <pre style={{ fontSize: '12px', color: '#61dafb' }}>
              {JSON.stringify(data, null, 2)}
            </pre>
          </div>
        )}
        
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
    </div>
  );
}

export default App;
