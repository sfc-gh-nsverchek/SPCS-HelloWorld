const express = require('express');
const path = require('path');
const https = require('https');
const http = require('http');
const url = require('url');
const app = express();
const PORT = process.env.PORT || 3000;
const BACKEND_SERVICE_NAME = process.env.BACKEND_SERVICE_NAME;
const BACKEND_SERVICE_PORT = process.env.BACKEND_SERVICE_PORT;

console.info('using env', process.env);

// Middleware to log request headers
app.use((req, res, next) => {
  console.log('Request Headers:', req.headers);
  next();
});

// Serve static files from the React app build directory
app.use(express.static(path.join(__dirname, 'build')));

// Catch all handler: only serve index.html for specific requests, forward others
app.all('*', (req, res) => {

  const currentUser = req.headers['sf-context-current-user'];
  // Log user details and request information
  console.log('User Request Details:', {
    user: currentUser || 'anonymous',
    method: req.method,
    path: req.path,
    originalUrl: req.originalUrl,
  });

  
  // Only serve index.html for root path, React routes, or specific UI requests
  if (req.path === '/' || req.path.startsWith('/static/') || 
      req.path.match(/\.(js|css|png|jpg|jpeg|gif|ico|svg)$/)) {
    res.sendFile(path.join(__dirname, 'build', 'index.html'));
  } else {
    // Forward all other requests to backend server
    const backendUrl = `http://${BACKEND_SERVICE_NAME}:${BACKEND_SERVICE_PORT}${req.originalUrl}`;

    console.log('Using backend url', backendUrl);

    // Proxy the request to the backend service
    const parsedUrl = url.parse(backendUrl);
    const isHttps = parsedUrl.protocol === 'https:';
    const client = isHttps ? https : http;
    
    const options = {
      hostname: parsedUrl.hostname,
      port: parsedUrl.port,
      path: parsedUrl.path,
      method: req.method,
      headers: {
        ...req.headers,
        host: parsedUrl.host
      }
    };
    
    const proxyReq = client.request(options, (proxyRes) => {
      // Set response headers from backend
      Object.keys(proxyRes.headers).forEach(key => {
        res.setHeader(key, proxyRes.headers[key]);
      });
      
      res.statusCode = proxyRes.statusCode;
      proxyRes.pipe(res);
    });
    
    proxyReq.on('error', (err) => {
      console.error('Proxy request error:', err);
      res.status(500).json({ error: 'Backend service unavailable' });
    });
    
    // Forward request body if present
    req.pipe(proxyReq);
  }
});


app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server is running on port ${PORT}`);
  console.log('Request headers will be logged to console');
});
